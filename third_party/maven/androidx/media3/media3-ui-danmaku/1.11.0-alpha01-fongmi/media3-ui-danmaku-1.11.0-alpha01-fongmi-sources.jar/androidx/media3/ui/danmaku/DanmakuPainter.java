/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.ui.danmaku;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import androidx.annotation.Nullable;
import androidx.media3.common.util.Util;
import java.util.List;
import java.util.Locale;

/** Owns paint configuration, text measurement, and rendering of active items. */
final class DanmakuPainter {

  private static final float DARK_LUMINANCE_THRESHOLD = 0.5f;
  private static final float COLORFUL_SATURATION = 0.55f;
  private static final float COLORFUL_VALUE = 1f;
  private static final float GRADIENT_HUE_OFFSET = 117f;
  private static final int[] GENERATED_GRADIENT = new int[0];
  private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
  private final Paint tailIconPaint =
      new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
  private final RectF tailIconRect = new RectF();
  private final Matrix gradientMatrix = new Matrix();
  private final float[] hsv = new float[3];
  private final PaintColorState fillState = new PaintColorState();
  private final PaintColorState strokeState = new PaintColorState();
  private final ShadowPaintState shadowState = new ShadowPaintState();
  private final DisplayMetrics displayMetrics;
  private DanmakuConfig config = DanmakuConfig.DEFAULT;
  private float textSizePx;
  private float trackHeight;
  private float currentPaintSizePx;
  private float lastStrokeWidth = -1f;

  DanmakuPainter(DisplayMetrics displayMetrics) {
    this.displayMetrics = displayMetrics;
    fillPaint.setStyle(Paint.Style.FILL);
    strokePaint.setStyle(Paint.Style.STROKE);
    setConfig(DanmakuConfig.DEFAULT);
  }

  private static int computeShadowColor(int textColor) {
    float red = Color.red(textColor) / 255f;
    float green = Color.green(textColor) / 255f;
    float blue = Color.blue(textColor) / 255f;
    float luminance = 0.2126f * red + 0.7152f * green + 0.0722f * blue;
    return luminance < DARK_LUMINANCE_THRESHOLD ? Color.WHITE : Color.BLACK;
  }

  private static int applyAlpha(int color, float alpha) {
    int clampedAlpha = (int) (255 * Util.constrainValue(alpha, 0f, 1f));
    return (color & 0x00FFFFFF) | (clampedAlpha << 24);
  }

  private static float hueOf(int textHash) {
    return (Math.abs(textHash) * 137.508f) % 360f;
  }

  void setConfig(DanmakuConfig config) {
    if (this.config.styleMode == DanmakuConfig.STYLE_SHADOW
        && config.styleMode != DanmakuConfig.STYLE_SHADOW) {
      shadowState.clearIfSet(fillPaint);
    }
    this.config = config;
    textSizePx = resolveTextSizePx(config.textSizeSp);
    float strokeWidthPx = textSizePx * config.strokeWidthMultiplier;
    trackHeight = textSizePx * config.lineSpacing;
    Typeface typeface = config.typeface != null ? config.typeface : Typeface.DEFAULT;
    fillPaint.setTextSize(textSizePx);
    fillPaint.setFakeBoldText(config.textBold);
    fillPaint.setTypeface(typeface);
    strokePaint.setTextSize(textSizePx);
    strokePaint.setStrokeWidth(strokeWidthPx);
    strokePaint.setFakeBoldText(config.textBold);
    strokePaint.setTypeface(typeface);
    currentPaintSizePx = textSizePx;
    shadowState.invalidate();
    lastStrokeWidth = strokeWidthPx;
    fillState.reset();
    strokeState.reset();
  }

  float textSizePx() {
    return textSizePx;
  }

  float trackHeight() {
    return trackHeight;
  }

  float resolveTextSizePx(float textSizeSp) {
    return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, textSizeSp, displayMetrics)
        * config.textScale;
  }

  /**
   * Occupied width of {@code item}: the one measurement every consumer shares (pool
   * admission accounting, speed and exit decisions in the track manager, draw geometry
   * here). It is the drawn width — text plus the like-count tail below — plus the item's
   * horizontal margin, which the embedder feeds per text-size tier; the margin travels
   * with the item as a layout property, exactly like the tail.
   */
  float measureWidth(DanmakuRenderItem item) {
    // A fresh measurement voids any speed-width override an earlier admission
    // decision wrote for a previous flight of this item.
    item.speedWidthOverride = 0f;
    float sizePx = item.textSizeSp > 0 ? resolveTextSizePx(item.textSizeSp) : textSizePx;
    fillPaint.setTextSize(sizePx);
    float body = fillPaint.measureText(item.text);
    float tail =
        tailWidth(item, fillPaint, sizePx, config.diggIconSizePx, tailGapPx(displayMetrics));
    item.bodyWidthPx = body;
    item.tailWidthPx = tail;
    float width = body + tail + config.horizontalMarginPx;
    fillPaint.setTextSize(textSizePx);
    // A configured surface measures on the official client's whole-pixel total
    // (its layout widths are ints); an unconfigured surface keeps the float total.
    return config.diggIconSizePx > 0f ? (float) Math.ceil(width) : width;
  }

  void remeasure(List<DanmakuRenderItem> items) {
    for (int i = 0; i < items.size(); i++) {
      DanmakuRenderItem item = items.get(i);
      float sizePx = item.textSizeSp > 0 ? resolveTextSizePx(item.textSizeSp) : textSizePx;
      if (fillPaint.getTextSize() != sizePx) {
        fillPaint.setTextSize(sizePx);
      }
      // Re-measurement voids any speed-width override from a previous flight.
      item.speedWidthOverride = 0f;
      float body = fillPaint.measureText(item.text);
      float tail =
          tailWidth(item, fillPaint, sizePx, config.diggIconSizePx, tailGapPx(displayMetrics));
      item.bodyWidthPx = body;
      item.tailWidthPx = tail;
      float width = body + tail + config.horizontalMarginPx;
      item.measuredWidth =
          config.diggIconSizePx > 0f ? (float) Math.ceil(width) : width;
    }
    fillPaint.setTextSize(textSizePx);
  }

  // ---- Like-count tail (official form: a tail piece after the text, icon + count) ----
  //
  // The official visibility rule is a server-side configuration
  // (danmaku_digg_v707: enable / digg_cnt threshold / show_cnt per
  // window_sec); its live values are not in the app package, so the
  // threshold below is a local set value. The label format in
  // diggTailText is not local: it is the official smartCountNumber,
  // copied branch for branch (see there).

  /** Minimum like count that earns the count tail. */
  static final long DIGG_TAIL_MIN_COUNT = 10;

  /**
   * Half the vertical row gap, in dp: a row's hit box widens by this much above
   * and below the row band (the official hit form reads the vertical tolerance
   * as half the row gap; the gap in the embedder's tier table is 4dp, so the
   * tolerance is 2dp). Converted with the display density only, like the tail
   * gaps.
   */
  private static final float HIT_ROW_TOLERANCE_DP = 2f;

  /**
   * Fixed gap of the configured tail form, in dp: text-to-icon and icon-to-count
   * (official client: 4dp on both sides of the tail icon). Converted with the
   * display density only — the tail gaps live in the same density space as the
   * fed icon size, not in the text-scale space.
   */
  static final float TAIL_GAP_DP = 4f;

  // Legacy proportional gaps, used only by the unconfigured tail form (surfaces
  // that never feed a tail icon size keep their historical measurement and
  // drawing exactly).
  private static final float TAIL_GAP_RATIO = 0.3f;
  private static final float TAIL_ICON_GAP_RATIO = 0.12f;

  /** The configured tail gap in pixels for {@code metrics}' density. */
  static float tailGapPx(DisplayMetrics metrics) {
    return TAIL_GAP_DP * metrics.density;
  }

  /**
   * Returns the tail label for {@code diggCount}, or null when the item gets no tail.
   *
   * <p>The format is the official com.dragon.read.util.NumberUtils.smartCountNumber copied
   * branch for branch — the same four branches (and the same float arithmetic) as the app-side
   * canonical HgTimeTextCount.format, so the flying tail and every app-side count read
   * identically: the wan tier truncates via /1000 and drops the fraction when the tenths digit
   * is 0 (10000/10500 → "1万", 1234567 → "123.4万"), the yi tier is the same shape (100000000 →
   * "1亿"), capped at "10亿".
   */
  static @Nullable String diggTailText(long diggCount) {
    if (diggCount < DIGG_TAIL_MIN_COUNT) {
      return null;
    }
    if (diggCount < 10_000) {
      return Long.toString(diggCount);
    }
    if (diggCount < 100_000_000) {
      long j = diggCount / 1000;
      return j % 10 == 0
          ? String.format(Locale.getDefault(), "%d万", j / 10)
          : String.format(Locale.getDefault(), "%.1f万", (j * 1.0f) / 10.0f);
    }
    if (diggCount < 1_000_000_000) {
      long j2 = diggCount / 10000000;
      return j2 % 10 == 0
          ? String.format(Locale.getDefault(), "%d亿", j2 / 10)
          : String.format(Locale.getDefault(), "%.1f亿", (j2 * 1.0f) / 10.0f);
    }
    long j3 = diggCount / 100000000;
    return j3 <= 10 ? "10亿" : String.format(Locale.getDefault(), "%d亿", j3);
  }

  /**
   * Width of the like-count tail of {@code item} at text size {@code sizePx}: the gap, the
   * icon when the configuration carries one, and the count label. The single tail formula
   * for both the painter (which owns the configured icon) and background measurement (which
   * only knows whether an icon is configured); {@code paint} must already be at {@code
   * sizePx}.
   *
   * <p>When the surface configured a tail icon size ({@code diggIconSizePx} &gt; 0), the
   * composition is the official client's: a fixed 4dp gap ({@code gapPx}), the tier icon
   * size, a fixed 4dp gap, and the count label's measured width. When it did not, the
   * legacy text-size-proportional composition is kept verbatim, so unconfigured surfaces
   * measure exactly as before.
   */
  static float tailWidth(
      DanmakuRenderItem item, Paint paint, float sizePx, float diggIconSizePx, float gapPx) {
    return tailWidth(item, paint, sizePx, true, diggIconSizePx, gapPx);
  }

  /** Icon-less variant of {@link #tailWidth(DanmakuRenderItem, Paint, float, float, float)}. */
  static float tailWidthWithoutIcon(
      DanmakuRenderItem item, Paint paint, float sizePx, float diggIconSizePx, float gapPx) {
    return tailWidth(item, paint, sizePx, false, diggIconSizePx, gapPx);
  }

  private static float tailWidth(
      DanmakuRenderItem item,
      Paint paint,
      float sizePx,
      boolean withIcon,
      float diggIconSizePx,
      float gapPx) {
    String tail = diggTailText(item.diggCount);
    if (tail == null) {
      return 0f;
    }
    if (diggIconSizePx > 0f) {
      float width = gapPx + paint.measureText(tail);
      if (withIcon) {
        width += diggIconSizePx + gapPx;
      }
      return width;
    }
    float width = sizePx * TAIL_GAP_RATIO + paint.measureText(tail);
    if (withIcon) {
      width += sizePx + sizePx * TAIL_ICON_GAP_RATIO;
    }
    return width;
  }

  DanmakuMeasurement measurement(int poolGeneration, int configGeneration) {
    return new DanmakuMeasurement(
        poolGeneration,
        configGeneration,
        textSizePx,
        config.textScale,
        displayMetrics,
        config.typeface != null ? config.typeface : Typeface.DEFAULT,
        config.textBold,
        config.horizontalMarginPx,
        config.diggIcon != null,
        config.diggIconSizePx);
  }

  void beginFrame() {
    currentPaintSizePx = textSizePx;
    fillPaint.setTextSize(textSizePx);
    strokePaint.setTextSize(textSizePx);
  }

  boolean draw(
      @Nullable Canvas canvas,
      DanmakuRenderItem item,
      long currentMs,
      int viewWidth,
      int viewHeight) {
    // A frozen item (tapped by the embedder, action UI open) is pinned at
    // the elapsed value captured when it froze; every other item keeps
    // following the live clock.
    long elapsedMs = item.frozen ? item.frozenElapsedMs : currentMs - item.activatedTimeMs;
    float sizePx = item.textSizeSp > 0 ? resolveTextSizePx(item.textSizeSp) : textSizePx;
    setPaintSize(sizePx);
    float x;
    float y;
    boolean alive;
    // Top of the item's row band (view coordinates), for the hit box below.
    float hitRowTop = 0f;
    switch (item.type) {
      case Danmaku.TYPE_SCROLL:
        float speed = (viewWidth + item.speedWidth()) / (float) effectiveScrollDurationMs();
        x = viewWidth - speed * elapsedMs;
        y = baseline(item.trackIndex, item.trackSpan) + scrollAreaOffsetPx(viewHeight);
        hitRowTop = item.trackIndex * trackHeight + scrollAreaOffsetPx(viewHeight);
        alive = x + item.measuredWidth > 0;
        break;
      case Danmaku.TYPE_REVERSE:
        float reverseSpeed = (viewWidth + item.speedWidth()) / (float) effectiveScrollDurationMs();
        x = -item.measuredWidth + reverseSpeed * elapsedMs;
        y = baseline(item.trackIndex, item.trackSpan) + scrollAreaOffsetPx(viewHeight);
        hitRowTop = item.trackIndex * trackHeight + scrollAreaOffsetPx(viewHeight);
        alive = x < viewWidth;
        break;
      case Danmaku.TYPE_TOP:
        x = (viewWidth - item.measuredWidth) / 2f;
        y = baseline(item.trackIndex, item.trackSpan);
        hitRowTop = item.trackIndex * trackHeight;
        alive = elapsedMs < config.fixedDurationMs;
        break;
      case Danmaku.TYPE_BOTTOM:
        x = (viewWidth - item.measuredWidth) / 2f;
        y = bottomBaseline(item.trackIndex, item.trackSpan, viewHeight);
        hitRowTop = viewHeight - (item.trackIndex + item.trackSpan) * trackHeight;
        alive = elapsedMs < config.fixedDurationMs;
        break;
      case Danmaku.TYPE_POSITIONED:
        long durationMs = item.durationMs > 0 ? item.durationMs : config.fixedDurationMs;
        x = item.x * viewWidth - item.measuredWidth / 2f;
        y = item.y * viewHeight;
        alive = elapsedMs < durationMs;
        break;
      default:
        return false;
    }
    if (!alive) {
      item.hitValid = false;
      return false;
    }
    // Record the hit box for embedder hit-testing
    // (DanmakuView.findDanmakuUserIdAt), in the official form: horizontally
    // the box is exactly the drawn extent — the body segment is the text's
    // measured width and the tail segment is the like-count tail's width
    // right after it (the same composition tailWidth measures); the item's
    // horizontal margin after the tail is layout space between items and is
    // never tappable. Vertically the box is the item's row band widened by
    // half the row gap on both sides. Positioned items have no row band and
    // keep the text-envelope box. findDanmakuBounds anchors on the same
    // union box (hitLeft..hitRight, hitTop..hitBottom).
    float textWidth = item.bodyWidthPx;
    float tailWidthPx = item.tailWidthPx;
    item.hitLeft = x;
    item.hitBodyRight = x + textWidth;
    item.hitRight = item.hitBodyRight + tailWidthPx;
    if (item.type == Danmaku.TYPE_POSITIONED) {
      item.hitTop = y - sizePx * 1.15f;
      item.hitBottom = y + sizePx * 0.45f;
    } else {
      float tolerancePx = HIT_ROW_TOLERANCE_DP * displayMetrics.density;
      item.hitTop = hitRowTop - tolerancePx;
      item.hitBottom = hitRowTop + item.trackSpan * trackHeight + tolerancePx;
    }
    item.hitValid = true;
    if (canvas != null) {
      drawAt(canvas, item, x, y, sizePx);
    }
    return true;
  }

  private void drawAt(Canvas canvas, DanmakuRenderItem item, float x, float y, float sizePx) {
    boolean forceWhite = shouldForceWhite(item);
    int color = forceWhite ? Color.WHITE : resolveColor(item);
    int alpha = (int) (Color.alpha(color) * (1f - config.transparency));
    fillState.apply(fillPaint, color, alpha);
    @Nullable int[] gradientColors = null;
    if (!forceWhite && config.colorMode == DanmakuConfig.COLOR_MODE_GRADIENT) {
      gradientColors = GENERATED_GRADIENT;
    } else if (!forceWhite
        && config.colorMode == DanmakuConfig.COLOR_MODE_DEFAULT
        && item.sourceGradientColors != null
        && item.sourceGradientColors.length >= 2) {
      gradientColors = item.sourceGradientColors;
    }
    if (gradientColors != null) {
      buildGradient(item, config.colorMode, gradientColors);
      gradientMatrix.setTranslate(x, 0);
      item.gradientShader.setLocalMatrix(gradientMatrix);
      fillPaint.setShader(item.gradientShader);
    }
    drawText(canvas, item.text, x, y, color, alpha, sizePx);
    drawDiggTail(canvas, item, x, y, color, alpha, sizePx);
    if (gradientColors != null) {
      fillPaint.setShader(null);
    }
  }

  /** Draws the like-count tail (optional icon + count) right after the item's text. */
  private void drawDiggTail(
      Canvas canvas, DanmakuRenderItem item, float x, float y, int color, int alpha, float sizePx) {
    String tail = diggTailText(item.diggCount);
    if (tail == null) {
      return;
    }
    // The drawn extent ends before the item's horizontal margin: the text
    // starts at x and the tail follows the text, margin excluded.
    // The drawn composition is the measured composition (tailWidth above): on
    // a configured surface the fixed 4dp gaps and the tier icon size,
    // otherwise the legacy text-size-proportional form.
    boolean configured = config.diggIconSizePx > 0f;
    float gapPx = configured ? tailGapPx(displayMetrics) : sizePx * TAIL_GAP_RATIO;
    float tailX = x + item.bodyWidthPx + gapPx;
    android.graphics.Bitmap icon = config.diggIcon;
    if (icon != null && !icon.isRecycled()) {
      android.graphics.Paint.FontMetrics metrics = fillPaint.getFontMetrics();
      float centerY = y + (metrics.ascent + metrics.descent) / 2f;
      float iconSize = configured ? config.diggIconSizePx : sizePx;
      float half = iconSize / 2f;
      tailIconRect.set(tailX, centerY - half, tailX + iconSize, centerY + half);
      tailIconPaint.setAlpha(alpha);
      canvas.drawBitmap(icon, null, tailIconRect, tailIconPaint);
      tailX += iconSize + (configured ? gapPx : sizePx * TAIL_ICON_GAP_RATIO);
    }
    drawText(canvas, tail, tailX, y, color, alpha, sizePx);
  }

  private int resolveColor(DanmakuRenderItem item) {
    if (config.colorMode != DanmakuConfig.COLOR_MODE_COLORFUL) {
      return item.color;
    }
    if (!item.generatedColorResolved) {
      item.generatedColor = hsvColor(hueOf(item.textHash));
      item.generatedColorResolved = true;
    }
    return item.generatedColor;
  }

  private boolean shouldForceWhite(DanmakuRenderItem item) {
    return (config.colorMode == DanmakuConfig.COLOR_MODE_COLORFUL
            || config.colorMode == DanmakuConfig.COLOR_MODE_GRADIENT)
        && item.forceGeneratedWhite;
  }

  private void buildGradient(DanmakuRenderItem item, int colorMode, int[] sourceColors) {
    if (item.gradientShader != null
        && item.gradientShaderWidth == item.measuredWidth
        && item.gradientShaderColorMode == colorMode) {
      return;
    }
    if (sourceColors.length == 0) {
      float hue = hueOf(item.textHash);
      item.gradientShader =
          new LinearGradient(
              0,
              0,
              item.measuredWidth,
              0,
              hsvColor(hue),
              hsvColor(hue + GRADIENT_HUE_OFFSET),
              Shader.TileMode.CLAMP);
    } else if (sourceColors.length == 2) {
      item.gradientShader =
          new LinearGradient(
              0, 0, item.measuredWidth, 0, sourceColors[0], sourceColors[1], Shader.TileMode.CLAMP);
    } else {
      float[] positions = new float[sourceColors.length];
      for (int i = 0; i < sourceColors.length; i++) {
        positions[i] = i / (float) (sourceColors.length - 1);
      }
      item.gradientShader =
          new LinearGradient(
              0, 0, item.measuredWidth, 0, sourceColors, positions, Shader.TileMode.CLAMP);
    }
    item.gradientShaderWidth = item.measuredWidth;
    item.gradientShaderColorMode = colorMode;
  }

  private void drawText(
      Canvas canvas, String text, float x, float y, int textColor, int alpha, float sizePx) {
    switch (config.styleMode) {
      case DanmakuConfig.STYLE_NONE:
        canvas.drawText(text, x, y, fillPaint);
        return;
      case DanmakuConfig.STYLE_SHADOW:
        int shadowColor = applyAlpha(computeShadowColor(textColor), 1f - config.shadowTransparency);
        shadowState.apply(fillPaint, shadowColor, sizePx * config.shadowRadiusMultiplier);
        canvas.drawText(text, x, y, fillPaint);
        return;
      case DanmakuConfig.STYLE_PROJECTION:
        drawProjection(canvas, text, x, y, textColor, sizePx);
        return;
      case DanmakuConfig.STYLE_STROKE:
      default:
        float strokeWidth = sizePx * config.strokeWidthMultiplier;
        if (lastStrokeWidth != strokeWidth) {
          strokePaint.setStrokeWidth(strokeWidth);
          lastStrokeWidth = strokeWidth;
        }
        strokeState.apply(strokePaint, computeShadowColor(textColor), alpha);
        canvas.drawText(text, x, y, strokePaint);
        canvas.drawText(text, x, y, fillPaint);
    }
  }

  private void drawProjection(
      Canvas canvas, String text, float x, float y, int textColor, float sizePx) {
    strokePaint.setStyle(Paint.Style.FILL);
    int projectionAlpha =
        (int)
            (255
                * Util.constrainValue(
                    (1f - config.projectionTransparency) * (1f - config.transparency), 0f, 1f));
    strokeState.apply(strokePaint, computeShadowColor(textColor), projectionAlpha);
    canvas.drawText(
        text,
        x + sizePx * config.projectionOffsetXMultiplier,
        y + sizePx * config.projectionOffsetYMultiplier,
        strokePaint);
    canvas.drawText(text, x, y, fillPaint);
    strokePaint.setStyle(Paint.Style.STROKE);
  }

  private void setPaintSize(float sizePx) {
    if (currentPaintSizePx != sizePx) {
      fillPaint.setTextSize(sizePx);
      strokePaint.setTextSize(sizePx);
      currentPaintSizePx = sizePx;
    }
  }

  private float scrollAreaOffsetPx(int viewHeight) {
    if (!config.scrollAreaBottom || trackHeight <= 0 || viewHeight <= 0) return 0f;
    int availableTracks = (int) (viewHeight / trackHeight);
    int scrollTracks = (int) (availableTracks * config.scrollAreaRatio);
    return Math.max(0, availableTracks - scrollTracks) * trackHeight;
  }

  private float baseline(int trackIndex, int trackSpan) {
    float trackTop = trackIndex * trackHeight;
    return trackTop + (trackSpan * trackHeight - fillPaint.descent() - fillPaint.ascent()) / 2f;
  }

  private float bottomBaseline(int trackIndex, int trackSpan, int viewHeight) {
    float trackTop = viewHeight - (trackIndex + trackSpan) * trackHeight;
    return trackTop + (trackSpan * trackHeight - fillPaint.descent() - fillPaint.ascent()) / 2f;
  }

  private long effectiveScrollDurationMs() {
    return Math.max(1L, (long) (config.durationMs / Math.max(0.01f, config.scrollSpeedFactor)));
  }

  private int hsvColor(float hue) {
    hsv[0] = ((hue % 360f) + 360f) % 360f;
    hsv[1] = COLORFUL_SATURATION;
    hsv[2] = COLORFUL_VALUE;
    return Color.HSVToColor(hsv);
  }
}
