/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.ui.danmaku;

import android.graphics.Shader;
import androidx.annotation.Nullable;

/** View-owned mutable rendering state copied from a danmaku source entry. */
final class DanmakuRenderItem {

  final String text;
  final String userId;
  final long diggCount;
  final long timeMs;
  final @Danmaku.Type int type;
  final int color;
  final float textSizeSp;
  final int pool;
  final float x;
  final float y;
  final long durationMs;
  final int textHash;
  final boolean forceGeneratedWhite;
  @Nullable final int[] sourceGradientColors;
  float measuredWidth;
  /**
   * Body text width from the same measurement that produced {@link #measuredWidth}
   * (draw geometry's text segment). Written by every measurement path that writes
   * measuredWidth; the painter reads it per frame instead of re-measuring the text.
   */
  float bodyWidthPx;
  /**
   * Like-count tail width (with-icon form, the form draw geometry uses) from the
   * same measurement that produced {@link #measuredWidth}.
   */
  float tailWidthPx;
  /**
   * Effective width for speed computation only, for this one flight: the track
   * manager's admission decision writes the previous item's speed width here when
   * a faster follower is admitted on the catch-up gate, so the follower flies at
   * exactly the previous item's speed (the official client's per-item effective
   * width). Zero means no override: speed reads {@link #measuredWidth}. Written
   * only by the admission decision; cleared when the item is re-measured, when a
   * fresh admission decision starts, and when the item is released from flight.
   * Never used by geometry, which always reads {@link #measuredWidth}.
   */
  float speedWidthOverride;

  /** The width speed computation must use for this item. */
  float speedWidth() {
    return speedWidthOverride > 0f ? speedWidthOverride : measuredWidth;
  }

  // Last drawn bounds (view coordinates), recorded by DanmakuPainter for
  // optional tap hit-testing by embedders. Invalid until first drawn frame.
  // hitLeft..hitRight is the union hit box: the body segment
  // (hitLeft..hitBodyRight, the text's measured width) followed by the tail
  // segment (hitBodyRight..hitRight, the like-count tail's width). The item's
  // horizontal margin is layout space after the tail and is not part of the
  // box. hitTop..hitBottom is the row band widened by half the row gap.
  float hitLeft;
  float hitBodyRight;
  float hitTop;
  float hitRight;
  float hitBottom;
  boolean hitValid;
  boolean liveItem;
  long liveExpiryElapsedRealtimeMs;
  int trackIndex = -1;
  int trackSpan = 1;
  long activatedTimeMs = -1;
  boolean active;
  // Single-item freeze (embedder tapped this item and opened its action UI):
  // while frozen, the painter uses frozenElapsedMs instead of the live clock
  // delta, pinning the item where it was tapped. Other items are unaffected.
  boolean frozen;
  long frozenElapsedMs;
  @Nullable Shader gradientShader;
  float gradientShaderWidth;
  int gradientShaderColorMode = -1;
  int generatedColor;
  boolean generatedColorResolved;

  DanmakuRenderItem(Danmaku danmaku) {
    text = danmaku.text;
    userId = danmaku.userId;
    diggCount = danmaku.diggCount;
    timeMs = danmaku.timeMs;
    type = danmaku.type;
    color = danmaku.color;
    textSizeSp = danmaku.textSizeSp;
    pool = danmaku.pool;
    x = danmaku.x;
    y = danmaku.y;
    durationMs = danmaku.durationMs;
    textHash = text.hashCode();
    forceGeneratedWhite = Math.abs(textHash) % 5 == 0;
    sourceGradientColors = danmaku.getSourceGradientColors();
    liveItem = danmaku.liveItem;
    liveExpiryElapsedRealtimeMs = danmaku.liveExpiryElapsedRealtimeMs;
  }
}
